public class reto1 {
    public static void main(String[] args) {
        int gradosK=350;
        double formulaC=273.15;

        double conversionGrados = gradosK - formulaC;

        System.out.print("la temperatura correcta sera " + conversionGrados);
    }

}
